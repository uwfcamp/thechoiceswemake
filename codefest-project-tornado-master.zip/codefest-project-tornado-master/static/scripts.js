function goToPage(link){
	window.location = link
}